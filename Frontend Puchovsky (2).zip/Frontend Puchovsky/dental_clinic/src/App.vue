<template>
  <div>
    <!-- Your template code here -->
    <header>
      <div>
        <nav>
          <RouterLink to="/">
            <img src="/public/zub.png" alt="Logo" class="logo" />
          </RouterLink>
          <RouterLink to="/about" class="nav-link">O nás</RouterLink>
          <RouterLink to="/order" class="nav-link">Objednať sa</RouterLink>
        </nav>
      </div>
    </header>

    <RouterView />

    <footer>
      <MyFooter />
    </footer>
  </div>
</template>

<script setup>
import { RouterLink, RouterView } from 'vue-router';
import MyFooter from '@/components/MyFooter.vue';

</script>

<style scoped>
/* Your scoped styles here */
</style>
